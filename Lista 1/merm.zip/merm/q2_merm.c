/* Extremamente Básico */

#include <stdio.h>

int main(){

    int A, B, X;

    scanf("%d\n", &A);
    scanf("%d\n", &B);

    X = A + B;
    printf("X = %d\n",X);

    return 0;

}