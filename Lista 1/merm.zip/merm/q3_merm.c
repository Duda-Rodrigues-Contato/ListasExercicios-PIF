/* Produto Simples*/

#include <stdio.h>

int main(){

    int valor1, valor2, PROD;

    scanf("%d", &valor1);
    scanf("%d", &valor2);

    PROD = valor1 * valor2;
    printf("PROD = %d\n",PROD);

    return 0;

}